# Contributing to FlightIQ

## Getting Started

1. Fork repository
2. Clone: `git clone <your-fork>`
3. Branch: `git checkout -b feature/my-feature`
4. Commit: `git commit -m "Add feature"`
5. Push: `git push origin feature/my-feature`
6. Create Pull Request

## Code Standards

- PEP 8 for Python
- Type hints required
- Docstrings for public functions
- Tests for new features
- Black for formatting

## Testing

```bash
docker exec -it flight_backend pytest
```
